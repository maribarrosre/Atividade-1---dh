var moradores = [
    "Fulano de Tal",
    "Beltrano da Cia",
    "Viajante do Tempo",
    "Morador da Lua",
    "Marciano Azul",
    "Et da Eslováquia",
    "Jedi do Lado Cinza da Força",
    "Baby Yoda Amarelo"
]
  var numeroDoApartamento = []
  for (var i = 0; i< numeroDoApartamento.length; i++){
} if( numeroDoApartamento%2==0){
  moradores.push(numeroDoApartamento[i])
}
console.log("O morador "+ moradores + " pode usar o elevador" )